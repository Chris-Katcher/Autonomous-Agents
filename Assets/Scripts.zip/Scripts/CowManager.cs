﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class CowManager : MonoBehaviour {

    public GameObject seekerGO;
    public GameObject cowGO;
    public GameObject cowPrefab;
    public GameObject pigPrefab;
    
    public GameObject go;
    private Vector3 SECow;
    private Vector3 NWCow;
    private Vector3 SEPig;
    private Vector3 NWPig;
    private Vector3 randPos;
    private float minX;
    private float maxX;
    private float minZ;
    private float maxZ;

    public List<GameObject> cows;
    public List<GameObject> pigs;
    // Use this for initialization
    void Start ()
    {
        
        Vector3 position = new Vector3(175.0f, 2.0f, 155.0f);
        cowGO = (GameObject)Instantiate(cowPrefab, position, Quaternion.identity);
        cowGO.transform.localScale = new Vector3(0.0035f, 0.0035f, 0.0035f);
        SECow = GameObject.Find("CowFenceSE").transform.position;
        NWCow = GameObject.Find("CowFenceNW").transform.position;

        SEPig = GameObject.Find("PigFenceSE").transform.position;
        NWPig = GameObject.Find("PigFenceNW").transform.position;

        minX = SECow.x;
        minZ = SECow.z;
        maxZ = NWCow.z;
        maxX = NWCow.x;

        cows = new List<GameObject>();
        //position = new Vector3(176.0f, 2.0f, 156.0f);
        //GameObject go = Instantiate(cowPrefab, position, Quaternion.identity) as GameObject;
        //go.transform.localScale = new Vector3(0.0035f, 0.0035f, 0.0035f);
        //cows[0] = go;
        for (int i = 0; i < 9; i++)
        {
            randPos = new Vector3(Random.Range(minX, maxX), 2, Random.Range(minZ, maxZ));
            go = (GameObject)Instantiate(cowPrefab, randPos, Quaternion.identity);
            go.transform.localScale = new Vector3(0.0035f, 0.0035f, 0.0035f);
           
            cows.Add(go);

            randPos = new Vector3(Random.Range(SEPig.x, NWPig.x), 0.25f, Random.Range(SEPig.z, NWPig.z));
            go = (GameObject)Instantiate(pigPrefab, randPos, Quaternion.identity);
            go.transform.localScale = new Vector3(.025f, .025f, .025f);
            pigs.Add(go);
            
        }
        
    }
	
	// Update is called once per frame
	void Update () {
	
	}

}
