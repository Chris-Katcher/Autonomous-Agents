﻿using UnityEngine;
using System.Collections;

public class Cow : Vehicle {

    private Vector3 SE;
    private Vector3 NW;
    private Vector3 minX;
    private Vector3 maxX;
    private Vector3 minZ;
    private Vector3 maxZ;
    private Vector3 steeringForce;
    private int fleeTimerMinx;
    private int fleeTimerMinz;
    private int fleeTimerMaxx;
    private int fleeTimerMaxz;

    private bool controlled;
    // Use this for initialization
    override public void Start ()
    {
        base.Start();
        SE = GameObject.Find("CowFenceSE").transform.position;
        NW = GameObject.Find("CowFenceNW").transform.position;
        
        //SE = Bound.GetComponent("CowFenceSE").transform.position;
        //NW = Bound.GetComponent("CowFenceNW").transform.position;
        minX = Vector3.zero;
        minX.x += SE.x;
        
        minZ = Vector3.zero;
        minZ.z += SE.z;
        maxX = Vector3.zero;
        maxX.x += NW.x;
        maxZ = Vector3.zero;
        maxZ.z += NW.z;
        controlled = false;
    }

    protected override void CalcSteeringForce()
    {
        // Reset "ultimate force" that will affect this seeker's movement
        steeringForce = Vector3.zero;

        //** THIS IS WHERE INDIVIDUAL STEERING FORCES ARE CALLED **
        
        
        //if (this.transform.position.x < minX.x + 10)
       // {
            //steeringForce += Seek(maxX) * Vector3.Distance(this.transform.position, NW)/10;
            //this.wanderAngle = Vector3.Angle(Vector3.zero, Seek(maxX));
           
       // }
        //if (this.transform.position.z < minZ.z + 10)
        //{
            //steeringForce += Seek(maxZ) * Vector3.Distance(this.transform.position, NW)/10;
        //}
        //if (this.transform.position.x > maxX.x - 10 )
        //{
            
            //steeringForce += Seek(minX) * Vector3.Distance(this.transform.position, SE)/10;
        //}
        //if (this.transform.position.z > maxZ.z - 10 )
        //{
           
            //steeringForce += Seek(minZ) * Vector3.Distance(this.transform.position, SE)/10;
        //}
       // else
        //{
        if(!controlled)
        {
            steeringForce += Wander();
        }
            
        //}
        
        
        

        

        // Don't allow the steering force to be too big
        steeringForce = Vector3.ClampMagnitude(steeringForce, maxForce);
        //this.wanderAngle = Vector3.Angle(Vector3.zero, steeringForce);
        // Have the "ultimate force" affect the seeker's movement
        ApplyForce(steeringForce);
    }

    public void setControled()
    {
        controlled = true;
        this.velocity = Vector3.zero;
    }
}
