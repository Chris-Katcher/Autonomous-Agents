﻿using UnityEngine;
using System.Collections;

//add using System.Collections.Generic; to use the generic list format
using System.Collections.Generic;

public class SimManager : MonoBehaviour {

    // A Seeker and the object of his desire
    public GameObject seekerGO;
    public List<GameObject> targetGO;
    public GameObject mainCharGO;
    public GameObject CowManagerGO;

    // Prefabs (the models to use when instantiating the above 2 GOs)
    public GameObject seekerPrefab;
    public GameObject targetPrefab;
    public GameObject mainCharPrefab;
    

    float dist;
    Vector3 randomPos;
	
    void Start () 
    {

        // Instantiate the target
        //  define a position
        // then instantiate the GO
        Vector3 position = new Vector3(0f, 40f, 0f);
        seekerGO = (GameObject)Instantiate(targetPrefab, position, Quaternion.identity);
        seekerGO.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);


        //// Instantiate the seeker
        //position = new Vector3(10f, 1f, 10f);
        //seekerGO = (GameObject)Instantiate(seekerPrefab, position, Quaternion.identity);

        //// Instantiate the main character
        //position = new Vector3(0f, 0f, 0f);
        //mainCharGO = (GameObject)Instantiate(mainCharPrefab, position, Quaternion.identity);

        //// Set the target for the seeker to the noodle
        seekerGO.GetComponent<Seeker>().CowManager = GameObject.Find("CowManagerGO");
        seekerGO.GetComponent<Seeker>().seekerTarget = GameObject.Find("CowManagerGO").GetComponent<CowManager>().cows;
        //mainCharGO.GetComponent<Runner>().seekerTarget = targetGO;
        //mainCharGO.GetComponent<Runner>().pursueTarget = seekerGO;
        //// Set the target for the Smooth Follow script:
        //// Gain access to Main camera - which has SmoothFollow script - which has 'target' var
        //// Set that target var to SeekerGO's 
        ////Camera.main.GetComponent<SmoothFollow>().target = seekerGO.transform;

    }
	

    void Update () 
    {

        //// Move the target when the googly-eye guy gets close
        //dist = Vector3.Distance(seekerGO.transform.position, targetGO[1].transform.position);
        //if (dist < 3)
        //{
        //    randomPos = new Vector3(Random.Range(-49, 49), 1f, Random.Range(-49, 49));
        //    targetGO.transform.position = randomPos;
        //}

    }
}
