using UnityEngine;
using System.Collections;

//add using System.Collections.Generic; to use the generic list format
using System.Collections.Generic;

public class Seeker : Vehicle {

    // Reference to this seeker's target
    public List<GameObject> seekerTarget;
    public GameObject CowManager;
    // Steering foce for this seeker
    private Vector3 steeringForce;

    // Call Inherited Start and then do our own
    override public void Start () 
    {
        base.Start();
        this.maxSpeed = 50;
    }
	

    // All child vehicles need to override CalcSteeringForce
    /// <summary>
    /// CalcSteeringForce method
    /// Accumulates steering vectors from multiple forces, like Seek and Flee, into one Ultimate Force
    /// Weights the steering force vectors
    /// Applies the resulting Ultimate Force to the vehicle's acceleration
    /// </summary>
    protected override void CalcSteeringForce()
    {
        // Reset "ultimate force" that will affect this seeker's movement
        steeringForce = Vector3.zero;

        CowManager.GetComponent<CowManager>().cows[1].GetComponent<Cow>().setControled();

        //** THIS IS WHERE INDIVIDUAL STEERING FORCES ARE CALLED **
        steeringForce += Approach(CowManager.GetComponent<CowManager>().cows[1].transform.position);

        // Don't allow the steering force to be too big
        steeringForce = Vector3.ClampMagnitude(steeringForce, maxForce);

        // Have the "ultimate force" affect the seeker's movement
        ApplyForce(steeringForce);
    }
}
