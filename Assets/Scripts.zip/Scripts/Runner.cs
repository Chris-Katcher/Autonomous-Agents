﻿using UnityEngine;
using System.Collections;

public class Runner : Vehicle {


    // Reference to this seeker's target
    public GameObject seekerTarget;
    public GameObject pursueTarget;
    public GameObject positionPrefab;
    public GameObject positionGO;

    Vector3 desiredPos;
    // Steering foce for this seeker
    private Vector3 steeringForce;

    // Use this for initialization
    override public void Start () {
        base.Start();
        positionGO = (GameObject)Instantiate(positionPrefab, desiredPos, Quaternion.identity);
    }

    // All child vehicles need to override CalcSteeringForce
    /// <summary>
    /// CalcSteeringForce method
    /// Accumulates steering vectors from multiple forces, like Seek and Flee, into one Ultimate Force
    /// Weights the steering force vectors
    /// Applies the resulting Ultimate Force to the vehicle's acceleration
    /// </summary>
    protected override void CalcSteeringForce()
    {
        // Reset "ultimate force" that will affect this seeker's movement
        steeringForce = Vector3.zero;

        //** THIS IS WHERE INDIVIDUAL STEERING FORCES ARE CALLED **

        // Seek the Blue Cylender
        if(Input.GetKey("s"))
        {
            steeringForce += Seek(seekerTarget.transform.position);
        }

        // Flee the blue Cylender
        if(Input.GetKey("f"))
        {
            steeringForce -= Seek(seekerTarget.transform.position);
        }

        // Pursue the orange Cube
        if(Input.GetKey("p"))
        {
            //desiredPos = new Vector3(3, 0, 3);
            desiredPos = pursueTarget.GetComponent<Vehicle>().getVelocity().normalized * 2;
            desiredPos = pursueTarget.transform.position + desiredPos; 
            steeringForce += Seek(desiredPos);
            positionGO.transform.position = desiredPos;
            
        }

        // Evade the orange Cube
        if(Input.GetKey("e"))
        {
            desiredPos = pursueTarget.GetComponent<Vehicle>().getVelocity().normalized * 2;
            desiredPos = pursueTarget.transform.position + desiredPos;
            steeringForce -= Seek(desiredPos);
            positionGO.transform.position = desiredPos;
        }
        
        // Don't allow the steering force to be too big
        steeringForce = Vector3.ClampMagnitude(steeringForce, maxForce);

        // Have the "ultimate force" affect the seeker's movement
        ApplyForce(steeringForce);
    }
}
