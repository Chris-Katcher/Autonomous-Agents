﻿using UnityEngine;
using System.Collections;

public class Pig : Vehicle
{

    private Vector3 SE;
    private Vector3 NW;
    private Vector3 minX;
    private Vector3 maxX;
    private Vector3 minZ;
    private Vector3 maxZ;
    private Vector3 steeringForce;

    // Use this for initialization
    void Start()
    {
        base.Start();
        SE = GameObject.Find("PigFenceSE").transform.position;
        NW = GameObject.Find("PigFenceNW").transform.position;

        //SE = Bound.GetComponent("CowFenceSE").transform.position;
        //NW = Bound.GetComponent("CowFenceNW").transform.position;
        minX = Vector3.zero;
        minX.x += SE.x;

        minZ = Vector3.zero;
        minZ.z += SE.z;
        maxX = Vector3.zero;
        maxX.x += NW.x;
        maxZ = Vector3.zero;
        maxZ.z += NW.z;
    }

    protected override void CalcSteeringForce()
    {
        // Reset "ultimate force" that will affect this seeker's movement
        steeringForce = Vector3.zero;

        //** THIS IS WHERE INDIVIDUAL STEERING FORCES ARE CALLED **

        steeringForce += Wander();

        // Don't allow the steering force to be too big
        steeringForce = Vector3.ClampMagnitude(steeringForce, maxForce);
        //this.wanderAngle = Vector3.Angle(Vector3.zero, steeringForce);
        // Have the "ultimate force" affect the seeker's movement
        ApplyForce(steeringForce);
    }
}
